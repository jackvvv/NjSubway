//全部站点数据
var menuNameArray = new Array("迈皋桥", "红山动物园", "南京站", "新模范马路", "玄武门", "鼓楼", "珠江路", "新街口", "张府园", "三山街", "中华门", "安德门", "小行", "中胜", "元通", "奥体中心", "天隆寺", "软件大道", "花神庙", "南京南站", "双龙大道", "河定桥", "胜太路", "百家湖", "小龙湾", "竹山路", "天印大道", "龙眠大道", "南医大·江苏经贸学院", "南京交院", "中国药科大学", "油坊桥", "雨润大街", "奥体东", "兴隆大街", "集庆门大街", "云锦路", "莫愁湖", "汉中门", "上海路", "大行宫", "西安门", "明故宫", "苜蓿园", "下马坊", "孝陵卫", "钟灵街", "马群", "金马路", "仙鹤门", "学则路", "仙林中心", "羊山公园", "南大仙林校区", "经天路", "雨山路", "文德路", "龙华路", "南京工业大学", "浦口万汇城", "临江", "江心洲", "绿博园", "梦都大街", "翠屏山", "河海大学·佛城西路", "吉印大道", "正方中路", "翔宇路北", "翔宇路南", "禄口机场", "泰山新村", "泰冯路", "高新开发区", "信息工程大学", "卸甲甸", "大厂", "葛塘", "长芦", "化工园", "六合开发区", "龙池", "雄州", "凤凰山公园", "方州广场", "沈桥", "八百桥", "金牛湖", "林场", "星火路", "东大成贤学院", "天润城", "柳州东路", "上元门", "五塘广场", "小市", "南京林业大学·新庄", "鸡鸣寺", "浮桥", "常府街", "夫子庙", "武定门", "雨花门", "卡子门", "大明路", "明发广场", "宏运大道", "胜太西路", "天元西路", "九龙湖", "诚信大道", "东大九龙湖校区", "秣周东路");
var sxs = new Array(2146,2068,1892,1848,1813,1805,1805,1806,1805,1805,1805,1806,1586,1434,1280,1102,1806,1806,1890,1981,2198,2198,2198,2226,2285,2360,2450,2504,2559,2618,2693,1574,1279,1279,1279,1279,1296,1418,1560,1687,1981,2086,2216,2332,2450,2572,2684,2819,2922,3004,3083,3152,3218,3288,3344,514,568,632,700,766,836,958,1102,1102,1884,1884,1884,1884,1884,1950,2135,1256,1376,1490,1586,1726,1856,1989,2163,2332,2482,2654,2837,3008,3227,3396,3518,3660,828,1092,1208,1424,1466,1603,1687,1766,1953,1980,1980,1980,1980,1980,1980,1980,1980,1980,1980,1980,1980,1980,1980,1980,1980);
var sys = new Array(1190,1266,1444,1486,1530,1599,1782,1960,2082,2156,2328,2504,2504,2504,2504,2398,2574,2634,2686,2686,2746,2850,2944,3042,3102,3177,3266,3320,3376,3434,3510,2900,2643,2416,2316,2218,2116,1992,1960,1960,1960,1872,1780,1780,1780,1780,1716,1581,1478,1396,1317,1248,1182,1112,1057,1572,1626,1690,1758,1824,1894,2016,2222,2309,2962,3120,3277,3434,3596,3810,3810,1049,928,815,720,637,637,637,637,637,637,637,637,637,637,637,637,637,518,643,758,975,1016,1154,1238,1317,1504,1599,1782,2082,2155,2266,2345,2420,2498,2578,2826,2922,3016,3114,3207,3302,3509);

var thisClickPosition=[];											 	 //当前点击对象的位置x,y,className,width
var _menu = document.getElementById("menu"),							 //弹出框
	_mask1 = document.getElementById("mask1"),	    					 //弹出框的透明背景层，用于取消弹出框
	_mask = document.getElementById("mask"),							 //结果的灰色背景层
	_mapDiv = document.getElementById("map").getElementsByTagName("div"),//所有的站点元素
	_startImg = document.getElementById("startImg"),					 //起点图标
	_endImg = document.getElementById("endImg"),						 //终点图标
	_canvas = document.getElementById("canvas"),                         //canvas对象
	_setStart = document.getElementById("setStart"),
	_setEnd = document.getElementById("setEnd");
var className = "";
var _startName = "",													 //保存起点，终点的名称
	 _endName = "";

Element.prototype.hide = function(){               						 //向Element的原型上添加显示和隐藏元素的方法
	this.style.display = "none";
};
Element.prototype.show =function(){
	this.style.display = "block";
};

_mask1.addEventListener("click",function(){         					 //用于点击空白区域时取消弹出框
	_menu.hide();
});


//获取点击站点的left，top，className，width
function getThisData(obj,name){
	className = name;
	thisClickPosition[0] = name+",";  		  //保存当前点击对象的内容
	thisClickPosition[1] = parseInt(obj.style.top);	  //保存当前点击对象的top
	thisClickPosition[2] = obj.className;			  //保存当前点击对象的className
	thisClickPosition[3] = parseInt(obj.style.width); //保存当前点击对象的width
	thisClickPosition[4] = obj;						  //保存当前点击的对象
	thisClickPosition[5] = true;
}		

//确定弹框位置,并显示
function selectStation(obj,name) {								//参数：1,点击的对象 2 ,弹框的left 3, 弹框的right
		var strname = "";
		getThisData(obj,name); 												//获取点击站点的left，top，className，width
		strname = name;										//获取点击站点的名称
		bombBox(strname);												//返回给app弹框的位置
};

//获取点击的是哪一个菜单按钮 为选中站点添加状态
function setStartEnd(obj,bool,setObj,name,boola){ 	 								//参数：1,点击的对象 "设为起点"or"设为终点"； 2,点击的哪一个按钮，true为"设为起点"，false为"设为终点"；3,app设置起点，终点需要的参数；								
	var _currentObj = null;
	if(setObj)
	{
		getThisData(setObj,name);
	}
	if(thisClickPosition[4].getAttribute("start") == "yes")
	{
		if(bool)
		{
			return false;
		}
		else
		{
			reset();
			addBuff(bool,4,"end",boola);
		}
	}
	else if(thisClickPosition[4].getAttribute("end") == "yes")
	{
		if(!bool)
		{
			return false;
		}
		else
		{
			reset();
			addBuff(bool,4,"start",boola);
		}
	}
	else
	{
		addBuff(bool,null,null,boola);
	}
	
};
//添加状态
function addBuff(bool){
	for(var i=0;i<menuNameArray.length;i++)								//为当前已设置为起点或者终点的站点，设置状态
	{
		//分别取消已选中站点状态
		if(bool)
		{
			if(_mapDiv[i].getAttribute("start") == "yes")
			{
				_mapDiv[i].setAttribute("start","");
			};
		}
		else
		{
			if(_mapDiv[i].getAttribute("end") == "yes")
			{
				_mapDiv[i].setAttribute("end","");
			};
		};
		//分别添加当前站点状态
		if(className == menuNameArray[i])
		{
			if(bool){
				_mapDiv[i].setAttribute("start","yes");
				_startName = className;         //保存当前起点名称
			}
			else
			{
				_mapDiv[i].setAttribute("end","yes");
				_endName = className;			//保存当前终点名称
			};
		};
	};
	if(bool) 				
	{
		ifPosition(_startImg,arguments[1],arguments[2],arguments[3]);
	}
	else
	{
		ifPosition(_endImg,arguments[1],arguments[2],arguments[3]);
	};
}

//设置起点，终点图标位置
function ifPosition(obj){  													//参数：1,要设置的图标对象；
	obj.style.left = coordinateTransformation(thisClickPosition[0],true)[0][0]-25+"px";
	obj.style.top = coordinateTransformation(thisClickPosition[0],true)[0][1]-66+"px";
	obj.show();
	
	if(!arguments[3]) {
		return false;
	}
	
	if(_startImg.style.display == "block" && _endImg.style.display == "block")  //判断是否选择完成
	{		
			appCall(3,_startName,_endName);
	}
	else if(arguments[1])
	{
		if(arguments[2] == "start")
		{
			
			appCall(4,_startName,"");
		}
		else
		{
			
			appCall(4,"",_endName);
		}	
	}
	else if(obj == _startImg)													
	{		
			appCall(1,_startName,"");
			_lastObj = [obj,];
	}
	else if(obj == _endImg)
	{

			_lastObj = [,obj];
			appCall(2,"",_endName)
	};

}

//转换app回来的数据
function coordinateTransformation(str,ble){  	   						//将返回的站点转成路径坐标，参数：1，站点数组 2，判断转为dom对象还是站点中心坐标
var arrCoordinate = [];													//将要返回的数组
var arr = str.split(",");												//字符串分割
	for(var i=0;i<arr.length;i++)
	{
		for(var n=0;n<menuNameArray.length;n++)
		{
			if(arr[i] == menuNameArray[n])
			{
				if(ble)
				{
					arrCoordinate[i] = [sxs[n],sys[n]];						 //将对象转换为站点中心坐标，供canvas画图
					continue;
				}
				else
				{
					arrCoordinate[i] = _mapDiv[n];     						//将对象转换为dom对象，供设置起点and终点
					continue;
				}
			}
		};
	};
	return arrCoordinate;
};
var close=null;
//canvas画线
function canvasOperation(routeArr){			
		window.cancelAnimationFrame(close);							//参数：1，路径数组
		for(var i=0;i<menuNameArray.length;i++)
		{
			_mapDiv[i].childNodes[0].hide();
		}
		_mask.show();														//显示灰色背景层											
		var time = 0														//上次执行的时间
		var i = 0;															//执行次数
		var arrLength = routeArr.length;									//路径数组长度
		//canvas动画主体
		function Operation(times){
			if(times - time >50)
			{
				time = times;
				routeArr[i].childNodes[0].show();
				i++;
				
			}
			if(i < arrLength){
				close = requestAnimationFrame(Operation);
			};
		};
		requestAnimationFrame(Operation); 
};


